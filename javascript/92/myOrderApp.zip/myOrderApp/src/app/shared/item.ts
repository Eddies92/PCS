export default interface Item {
    name: string;
    brand: string;
    price: number;
}