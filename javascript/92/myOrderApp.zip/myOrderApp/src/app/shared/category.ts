import Item from './item';

export default interface Category {
    names: string[],
    item: Item;
}
